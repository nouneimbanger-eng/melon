package com.melo.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.melo.app.data.MeloStorage
import com.melo.app.data.model.Chat
import com.melo.app.data.model.ChatType
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewGroupScreen(onBack: () -> Unit, onCreated: (String) -> Unit) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    val scope = rememberCoroutineScope()
    var groupName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Новая группа") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (groupName.isNotBlank()) {
                                scope.launch {
                                    val id = UUID.randomUUID().toString()
                                    val current = storage.chats.first().toMutableList()
                                    current.add(0, Chat(
                                        id = id,
                                        title = groupName.trim(),
                                        type = ChatType.GROUP,
                                        lastMessage = "Группа создана"
                                    ))
                                    storage.saveChats(current)
                                    onCreated(id)
                                }
                            }
                        },
                        enabled = groupName.isNotBlank()
                    ) {
                        Icon(
                            Icons.Default.Check, contentDescription = "Создать",
                            tint = if (groupName.isNotBlank()) colors.primary else colors.secondaryText
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = groupName,
                onValueChange = { groupName = it },
                label = { Text("Название группы") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.primary,
                    unfocusedBorderColor = colors.secondaryText,
                    focusedLabelColor = colors.primary,
                    focusedTextColor = colors.onBackground,
                    unfocusedTextColor = colors.onBackground
                )
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Группа сохранится на этом устройстве.",
                color = colors.secondaryText,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
