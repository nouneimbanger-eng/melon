package com.melo.app.data.model

import java.util.UUID

data class UserProfile(
    val id: String = "me",
    val name: String = "Melo User",
    val username: String = "melo_user",
    val bio: String = "Привет! Это мой профиль в Melo ✨",
    val avatarPath: String? = null,
    val bannerPath: String? = null,
    val phone: String = ""
)

enum class ChatType {
    PRIVATE, GROUP, CHANNEL
}

data class Chat(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: ChatType = ChatType.PRIVATE,
    val avatarPath: String? = null,
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val members: List<String> = emptyList(),
    val isMuted: Boolean = false,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false
)

enum class MessageType {
    TEXT, IMAGE, VIDEO, FILE, MUSIC, VOICE, STICKER, SYSTEM
}

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val chatId: String,
    val senderId: String,
    val type: MessageType = MessageType.TEXT,
    val text: String = "",
    val mediaPath: String? = null,
    val fileName: String? = null,
    val voiceDuration: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val isOutgoing: Boolean = true,
    val isRead: Boolean = false,
    val replyToId: String? = null
)

data class Story(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val mediaPath: String,
    val caption: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 24 * 60 * 60 * 1000,
    val viewedBy: List<String> = emptyList()
)

data class AppSettings(
    val theme: String = "DARK",
    val notificationsEnabled: Boolean = true
)

data class NoxesData(
    val balance: Long = 0L,
    val totalEarned: Long = 0L,
    val totalSpent: Long = 0L
)
