package com.melo.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.melo.app.data.model.Message
import com.melo.app.data.model.MessageType
import com.melo.app.ui.theme.LocalMeloColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(chatId: String, onBack: () -> Unit) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    var messageText by remember { mutableStateOf("") }
    var showAttachMenu by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf(
            Message(chatId = chatId, senderId = "other", text = "Привет! Как дела?", isOutgoing = false, timestamp = System.currentTimeMillis() - 600000),
            Message(chatId = chatId, senderId = "me", text = "Нормально! А у тебя?", isOutgoing = true, timestamp = System.currentTimeMillis() - 500000),
            Message(chatId = chatId, senderId = "other", text = "Тоже хорошо. Что нового?", isOutgoing = false, timestamp = System.currentTimeMillis() - 400000),
        )
    }

    // Pickers
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            messages.add(Message(chatId = chatId, senderId = "me", type = MessageType.IMAGE, text = "Фото", mediaPath = it.toString(), isOutgoing = true))
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            messages.add(Message(chatId = chatId, senderId = "me", type = MessageType.VIDEO, text = "Видео", mediaPath = it.toString(), isOutgoing = true))
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val name = it.lastPathSegment ?: "Файл"
            messages.add(Message(chatId = chatId, senderId = "me", type = MessageType.FILE, text = name, mediaPath = it.toString(), fileName = name, isOutgoing = true))
        }
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val name = it.lastPathSegment ?: "Музыка"
            messages.add(Message(chatId = chatId, senderId = "me", type = MessageType.MUSIC, text = name, mediaPath = it.toString(), fileName = name, isOutgoing = true))
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) isRecording = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Чат", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("в сети", fontSize = 13.sp, color = colors.secondaryText)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.Call, contentDescription = "Звонок") }
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, contentDescription = "Ещё") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground,
                    actionIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background,
        bottomBar = {
            Column {
                if (showAttachMenu) {
                    AttachMenu(
                        onPhoto = { showAttachMenu = false; imagePicker.launch("image/*") },
                        onVideo = { showAttachMenu = false; videoPicker.launch("video/*") },
                        onFile = { showAttachMenu = false; filePicker.launch("*/*") },
                        onMusic = { showAttachMenu = false; musicPicker.launch("audio/*") },
                        onDismiss = { showAttachMenu = false }
                    )
                }
                MessageInputBar(
                    text = messageText,
                    isRecording = isRecording,
                    onTextChange = { messageText = it },
                    onSend = {
                        if (messageText.isNotBlank()) {
                            messages.add(Message(chatId = chatId, senderId = "me", text = messageText.trim(), isOutgoing = true))
                            messageText = ""
                        }
                    },
                    onAttach = { showAttachMenu = !showAttachMenu },
                    onVoiceStart = {
                        val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (hasPermission) {
                            isRecording = true
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onVoiceStop = {
                        isRecording = false
                        messages.add(
                            Message(
                                chatId = chatId,
                                senderId = "me",
                                type = MessageType.VOICE,
                                text = "Голосовое сообщение",
                                voiceDuration = (3..15).random(),
                                isOutgoing = true
                            )
                        )
                    }
                )
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message = message)
            }
        }
    }
}

@Composable
fun AttachMenu(
    onPhoto: () -> Unit,
    onVideo: () -> Unit,
    onFile: () -> Unit,
    onMusic: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMeloColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surface)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        AttachItem(Icons.Default.Image, "Фото", Color(0xFF4CAF50), onPhoto)
        AttachItem(Icons.Default.Videocam, "Видео", Color(0xFFE91E63), onVideo)
        AttachItem(Icons.Default.InsertDriveFile, "Файл", Color(0xFF2196F3), onFile)
        AttachItem(Icons.Default.MusicNote, "Музыка", Color(0xFFFF9800), onMusic)
    }
}

@Composable
fun AttachItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(48.dp).clip(CircleShape).background(color.copy(0.15f))
        ) {
            Icon(icon, contentDescription = label, tint = color)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, color = LocalMeloColors.current.secondaryText)
    }
}

@Composable
fun MessageBubble(message: Message) {
    val colors = LocalMeloColors.current
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp, topEnd = 16.dp,
                        bottomStart = if (message.isOutgoing) 16.dp else 4.dp,
                        bottomEnd = if (message.isOutgoing) 4.dp else 16.dp
                    )
                )
                .background(if (message.isOutgoing) colors.bubbleOut else colors.bubbleIn)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column {
                when (message.type) {
                    MessageType.IMAGE -> {
                        MediaPlaceholder(Icons.Default.Image, "Фото", Color(0xFF4CAF50))
                    }
                    MessageType.VIDEO -> {
                        MediaPlaceholder(Icons.Default.Videocam, "Видео", Color(0xFFE91E63))
                    }
                    MessageType.FILE -> {
                        MediaPlaceholder(Icons.Default.InsertDriveFile, message.fileName ?: "Файл", Color(0xFF2196F3))
                    }
                    MessageType.MUSIC -> {
                        MediaPlaceholder(Icons.Default.MusicNote, message.fileName ?: "Музыка", Color(0xFFFF9800))
                    }
                    MessageType.VOICE -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, tint = colors.primary, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(8.dp))
                            // Waveform fake
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                repeat(12) { i ->
                                    Box(
                                        Modifier
                                            .width(3.dp)
                                            .height((8 + (i % 5) * 4).dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(colors.primary.copy(0.6f))
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Text("${message.voiceDuration}\"", fontSize = 12.sp, color = colors.secondaryText)
                        }
                    }
                    else -> {
                        Text(message.text, color = colors.onBackground, fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    timeFormat.format(Date(message.timestamp)),
                    fontSize = 11.sp,
                    color = colors.secondaryText,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
fun MediaPlaceholder(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(color.copy(0.15f))
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = LocalMeloColors.current.onBackground)
    }
}

@Composable
fun MessageInputBar(
    text: String,
    isRecording: Boolean,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onAttach: () -> Unit,
    onVoiceStart: () -> Unit,
    onVoiceStop: () -> Unit
) {
    val colors = LocalMeloColors.current

    Row(
        modifier = Modifier.fillMaxWidth().background(colors.surface).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!isRecording) {
            IconButton(onClick = onAttach) {
                Icon(Icons.Default.AttachFile, contentDescription = "Прикрепить", tint = colors.secondaryText)
            }
            TextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение", color = colors.secondaryText) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = colors.background,
                    unfocusedContainerColor = colors.background,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = colors.onBackground,
                    unfocusedTextColor = colors.onBackground
                ),
                shape = RoundedCornerShape(20.dp),
                maxLines = 4
            )
            Spacer(Modifier.width(4.dp))
            if (text.isBlank()) {
                IconButton(onClick = onVoiceStart) {
                    Icon(Icons.Default.Mic, contentDescription = "Голосовое", tint = colors.primary)
                }
            } else {
                IconButton(onClick = onSend) {
                    Icon(Icons.Default.Send, contentDescription = "Отправить", tint = colors.primary)
                }
            }
        } else {
            // Recording UI
            Icon(Icons.Default.Mic, null, tint = Color.Red, modifier = Modifier.padding(start = 12.dp))
            Spacer(Modifier.width(8.dp))
            Text("Запись...", color = Color.Red, modifier = Modifier.weight(1f))
            TextButton(onClick = onVoiceStop) {
                Text("Отправить", color = colors.primary)
            }
            TextButton(onClick = onVoiceStop) {
                Text("Отмена", color = colors.secondaryText)
            }
        }
    }
}
