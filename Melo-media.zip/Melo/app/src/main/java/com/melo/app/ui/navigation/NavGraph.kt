package com.melo.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.melo.app.ui.screens.*
import com.melo.app.ui.theme.LocalMeloColors
import com.melo.app.ui.theme.MeloTheme

sealed class Screen(val route: String) {
    object Chats : Screen("chats")
    object Chat : Screen("chat/{chatId}") {
        fun createRoute(chatId: String) = "chat/$chatId"
    }
    object Profile : Screen("profile")
    object EditProfile : Screen("edit_profile")
    object Settings : Screen("settings")
    object Stories : Screen("stories")
    object CreateStory : Screen("create_story")
    object NewGroup : Screen("new_group")
    object Noxes : Screen("noxes")
}

data class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun MeloNavGraph(
    currentTheme: MeloTheme,
    onThemeChange: (MeloTheme) -> Unit
) {
    val navController = rememberNavController()
    val colors = LocalMeloColors.current
    
    val bottomItems = listOf(
        BottomNavItem(Screen.Chats.route, "Чаты", Icons.Default.Chat),
        BottomNavItem(Screen.Noxes.route, "Ноксы", Icons.Default.Star),
        BottomNavItem(Screen.Profile.route, "Профиль", Icons.Default.Person)
    )
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    // Показываем нижнюю панель только на главных вкладках
    val showBottomBar = currentRoute in listOf(
        Screen.Chats.route,
        Screen.Noxes.route,
        Screen.Profile.route
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = colors.surface
                ) {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(Screen.Chats.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(item.icon, contentDescription = item.title)
                            },
                            label = { Text(item.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = colors.primary,
                                selectedTextColor = colors.primary,
                                unselectedIconColor = colors.secondaryText,
                                unselectedTextColor = colors.secondaryText,
                                indicatorColor = colors.primary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chats.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Chats.route) {
                ChatsScreen(
                    onChatClick = { chatId ->
                        navController.navigate(Screen.Chat.createRoute(chatId))
                    },
                    onProfileClick = {
                        navController.navigate(Screen.Profile.route)
                    },
                    onNewGroupClick = {
                        navController.navigate(Screen.NewGroup.route)
                    },
                    onStoriesClick = {
                        navController.navigate(Screen.Stories.route)
                    }
                )
            }

            composable(Screen.Noxes.route) {
                NoxesScreen()
            }

            composable(
                route = Screen.Chat.route,
                arguments = listOf(navArgument("chatId") { type = NavType.StringType })
            ) { backStackEntry ->
                val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
                ChatScreen(
                    chatId = chatId,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Profile.route) {
                ProfileScreen(
                    onBack = { navController.popBackStack() },
                    onEditProfile = { navController.navigate(Screen.EditProfile.route) },
                    onSettings = { navController.navigate(Screen.Settings.route) },
                    onStories = { navController.navigate(Screen.Stories.route) }
                )
            }

            composable(Screen.EditProfile.route) {
                EditProfileScreen(
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    currentTheme = currentTheme,
                    onThemeChange = onThemeChange,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Stories.route) {
                StoriesScreen(
                    onBack = { navController.popBackStack() },
                    onCreateStory = { navController.navigate(Screen.CreateStory.route) }
                )
            }

            composable(Screen.CreateStory.route) {
                CreateStoryScreen(
                    onBack = { navController.popBackStack() },
                    onPublished = { navController.popBackStack() }
                )
            }

            composable(Screen.NewGroup.route) {
                NewGroupScreen(
                    onBack = { navController.popBackStack() },
                    onCreated = { chatId ->
                        navController.popBackStack()
                        navController.navigate(Screen.Chat.createRoute(chatId))
                    }
                )
            }
        }
    }
}
