package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.MeloStorage
import com.melo.app.data.model.Story
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoriesScreen(onBack: () -> Unit, onCreateStory: () -> Unit) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    var stories by remember { mutableStateOf<List<Story>>(emptyList()) }

    LaunchedEffect(Unit) {
        stories = storage.stories.first()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Истории") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateStory, containerColor = colors.primary, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Новая история")
            }
        },
        containerColor = colors.background
    ) { padding ->
        if (stories.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Пока нет историй\nНажми + чтобы добавить", color = colors.secondaryText, fontSize = 16.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(stories) { story ->
                    Box(
                        modifier = Modifier.aspectRatio(0.7f).clip(RoundedCornerShape(12.dp))
                            .background(colors.primary.copy(0.25f)).clickable { }
                    ) {
                        Text(
                            story.caption.ifBlank { "История" },
                            color = colors.onBackground,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}
