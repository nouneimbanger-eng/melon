package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.MeloStorage
import com.melo.app.data.model.Story
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStoryScreen(onBack: () -> Unit, onPublished: () -> Unit) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    val scope = rememberCoroutineScope()
    var caption by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Новая история") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        scope.launch {
                            val current = storage.stories.first().toMutableList()
                            current.add(0, Story(
                                id = UUID.randomUUID().toString(),
                                userId = "me",
                                mediaPath = "",
                                caption = caption.ifBlank { "Моя история" }
                            ))
                            storage.saveStories(current)
                            onPublished()
                        }
                    }) {
                        Text("Опубликовать", color = colors.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth().weight(1f).background(colors.surface, MaterialTheme.shapes.medium)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Image, null, tint = colors.secondaryText, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Выберите фото или видео", color = colors.secondaryText)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = colors.primary)) {
                    Icon(Icons.Default.CameraAlt, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Камера")
                }
                OutlinedButton(onClick = {}) {
                    Icon(Icons.Default.Image, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Галерея")
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = caption, onValueChange = { caption = it },
                placeholder = { Text("Добавить подпись...", color = colors.secondaryText) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.primary,
                    unfocusedBorderColor = colors.secondaryText,
                    focusedTextColor = colors.onBackground,
                    unfocusedTextColor = colors.onBackground
                )
            )
        }
    }
}
