package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.MeloStorage
import com.melo.app.data.model.UserProfile
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onSettings: () -> Unit,
    onStories: () -> Unit
) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    var profile by remember { mutableStateOf(UserProfile()) }

    LaunchedEffect(Unit) {
        profile = storage.profile.first()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Профиль") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = onEditProfile) {
                        Icon(Icons.Default.Edit, contentDescription = "Редактировать")
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(220.dp)) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            listOf(colors.primary.copy(0.8f), colors.primary.copy(0.4f), colors.background)
                        )
                    )
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.align(Alignment.BottomCenter).offset(y = 40.dp)
                        .size(100.dp).clip(CircleShape).background(colors.surface)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(94.dp).clip(CircleShape).background(colors.primary.copy(0.3f))
                    ) {
                        Text(profile.name.firstOrNull()?.toString() ?: "M", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = colors.primary)
                    }
                }
            }
            Spacer(Modifier.height(50.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(profile.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = colors.onBackground)
                Text("@${profile.username}", fontSize = 15.sp, color = colors.secondaryText)
            }
            Spacer(Modifier.height(16.dp))
            if (profile.bio.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Text(profile.bio, Modifier.padding(16.dp), color = colors.onBackground, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(24.dp))
            ProfileActionItem(Icons.Default.AutoStories, "Истории", "Смотреть и добавлять", onStories)
            ProfileActionItem(Icons.Default.Edit, "Изменить профиль", "Имя, фото, описание", onEditProfile)
            ProfileActionItem(Icons.Default.Settings, "Настройки", "Темы, уведомления", onSettings)
        }
    }
}

@Composable
fun ProfileActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    ListItem(
        headlineContent = { Text(title, color = colors.onBackground) },
        supportingContent = { Text(subtitle, color = colors.secondaryText) },
        leadingContent = { Icon(icon, null, tint = colors.primary) },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
