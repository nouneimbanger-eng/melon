package com.melo.app.data.model

/**
 * Лимитированные подарки за Ноксы
 */

enum class GiftRarity {
    COMMON,      // обычный
    RARE,        // редкий
    EPIC,        // эпический
    LEGENDARY    // легендарный
}

data class NoxGift(
    val id: String,
    val name: String,
    val description: String,
    val basePrice: Long,                    // цена в Ноксах
    val upgradePrice: Long,                 // цена улучшения
    val maxUpgrades: Int = 1,               // сколько раз можно улучшить
    val rarity: GiftRarity = GiftRarity.COMMON,
    val emoji: String,
    val isLimited: Boolean = true
)

// Базовые подарки
val allNoxGifts = listOf(
    NoxGift(
        id = "pumpkin",
        name = "Тыква",
        description = "Классическая хэллоуинская тыква. Можно улучшить.",
        basePrice = 150,
        upgradePrice = 25,
        maxUpgrades = 1,
        rarity = GiftRarity.COMMON,
        emoji = "🎃"
    ),
    NoxGift(
        id = "witch_hat",
        name = "Шляпа ведьмы",
        description = "Остроконечная шляпа настоящей ведьмы.",
        basePrice = 225,
        upgradePrice = 35,
        maxUpgrades = 1,
        rarity = GiftRarity.COMMON,
        emoji = "🧙"
    ),
    NoxGift(
        id = "black_cat",
        name = "Чёрный кот",
        description = "Мистический чёрный кот. Приносит удачу... или нет.",
        basePrice = 280,
        upgradePrice = 40,
        maxUpgrades = 1,
        rarity = GiftRarity.RARE,
        emoji = "🐈‍⬛"
    ),
    NoxGift(
        id = "cauldron",
        name = "Котёл ведьмы",
        description = "Булькающий котёл с зельем.",
        basePrice = 350,
        upgradePrice = 45,
        maxUpgrades = 1,
        rarity = GiftRarity.RARE,
        emoji = "🧉"
    ),
    NoxGift(
        id = "ghost",
        name = "Призрак",
        description = "Настоящий призрак. Самый редкий и дорогой подарок.",
        basePrice = 500,
        upgradePrice = 50,
        maxUpgrades = 1,
        rarity = GiftRarity.EPIC,
        emoji = "👻"
    )
)

/**
 * Возможные результаты улучшения (рандом)
 * Шанс указан примерно
 */
data class UpgradeVariant(
    val id: String,
    val parentGiftId: String,
    val name: String,
    val description: String,
    val rarity: GiftRarity,
    val chancePercent: Int,          // шанс выпадения
    val emoji: String
)

val upgradeVariants = listOf(
    // ===== Тыква =====
    UpgradeVariant("pumpkin_ghostly", "pumpkin", "Призрачная тыква", "Прозрачно-зелёная светящаяся тыква", GiftRarity.RARE, 10, "🎃"),
    UpgradeVariant("pumpkin_golden", "pumpkin", "Золотая тыква", "Блестящая золотая тыква", GiftRarity.EPIC, 5, "🎃"),
    UpgradeVariant("pumpkin_cursed", "pumpkin", "Проклятая тыква", "Тёмная тыква с красными глазами", GiftRarity.RARE, 15, "🎃"),
    UpgradeVariant("pumpkin_tiny", "pumpkin", "Маленькая тыква", "Крошечная милая тыковка", GiftRarity.COMMON, 40, "🎃"),
    UpgradeVariant("pumpkin_giant", "pumpkin", "Гигантская тыква", "Огромная тыква", GiftRarity.RARE, 20, "🎃"),

    // ===== Шляпа ведьмы =====
    UpgradeVariant("hat_crystal", "witch_hat", "Кристальная шляпа", "Шляпа из фиолетового кристалла", GiftRarity.EPIC, 8, "🧙"),
    UpgradeVariant("hat_shadow", "witch_hat", "Теневая шляпа", "Шляпа из чистой тьмы", GiftRarity.RARE, 12, "🧙"),
    UpgradeVariant("hat_flower", "witch_hat", "Цветочная шляпа", "Шляпа, украшенная цветами", GiftRarity.COMMON, 35, "🧙"),
    UpgradeVariant("hat_fire", "witch_hat", "Огненная шляпа", "Шляпа с языками пламени", GiftRarity.EPIC, 7, "🧙"),
    UpgradeVariant("hat_star", "witch_hat", "Звёздная шляпа", "Шляпа, усыпанная звёздами", GiftRarity.RARE, 18, "🧙"),

    // ===== Чёрный кот =====
    UpgradeVariant("cat_ghost", "black_cat", "Призрачный кот", "Полупрозрачный светящийся кот", GiftRarity.EPIC, 9, "🐈‍⬛"),
    UpgradeVariant("cat_witch", "black_cat", "Кот ведьмы", "Кот в маленькой шляпе", GiftRarity.RARE, 15, "🐈‍⬛"),
    UpgradeVariant("cat_golden", "black_cat", "Золотой кот", "Кот с золотой шерстью", GiftRarity.LEGENDARY, 3, "🐈‍⬛"),
    UpgradeVariant("cat_sleepy", "black_cat", "Сонный кот", "Кот, который постоянно спит", GiftRarity.COMMON, 40, "🐈‍⬛"),
    UpgradeVariant("cat_angry", "black_cat", "Злой кот", "Кот с красными глазами", GiftRarity.RARE, 13, "🐈‍⬛"),

    // ===== Котёл =====
    UpgradeVariant("cauldron_poison", "cauldron", "Ядовитый котёл", "Котёл с ярко-зелёным зельем", GiftRarity.RARE, 14, "🧉"),
    UpgradeVariant("cauldron_love", "cauldron", "Котёл любви", "Котёл с розовым зельем", GiftRarity.COMMON, 30, "🧉"),
    UpgradeVariant("cauldron_void", "cauldron", "Котёл пустоты", "Котёл, из которого идёт тьма", GiftRarity.EPIC, 6, "🧉"),
    UpgradeVariant("cauldron_gold", "cauldron", "Золотой котёл", "Котёл из чистого золота", GiftRarity.LEGENDARY, 4, "🧉"),
    UpgradeVariant("cauldron_bubble", "cauldron", "Бурлящий котёл", "Очень активно булькает", GiftRarity.COMMON, 35, "🧉"),

    // ===== Призрак =====
    UpgradeVariant("ghost_king", "ghost", "Король призраков", "Призрак в короне", GiftRarity.LEGENDARY, 5, "👻"),
    UpgradeVariant("ghost_cute", "ghost", "Милый призрак", "Маленький добрый призрак", GiftRarity.COMMON, 30, "👻"),
    UpgradeVariant("ghost_dark", "ghost", "Тёмный призрак", "Почти чёрный зловещий призрак", GiftRarity.EPIC, 10, "👻"),
    UpgradeVariant("ghost_rainbow", "ghost", "Радужный призрак", "Призрак всех цветов", GiftRarity.RARE, 15, "👻"),
    UpgradeVariant("ghost_tiny", "ghost", "Крошечный призрак", "Очень маленький призрак", GiftRarity.COMMON, 25, "👻")
)
