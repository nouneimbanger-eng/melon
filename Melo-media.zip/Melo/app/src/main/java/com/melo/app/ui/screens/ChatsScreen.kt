package com.melo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.MeloStorage
import com.melo.app.data.model.Chat
import com.melo.app.data.model.ChatType
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(
    onChatClick: (String) -> Unit,
    onProfileClick: () -> Unit,
    onNewGroupClick: () -> Unit,
    onStoriesClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    val scope = rememberCoroutineScope()

    var showArchived by remember { mutableStateOf(false) }
    var showCreateMenu by remember { mutableStateOf(false) }
    var chatToDelete by remember { mutableStateOf<Chat?>(null) }
    var chats by remember { mutableStateOf<List<Chat>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        chats = storage.chats.first()
        loaded = true
    }

    LaunchedEffect(chats) {
        if (loaded) storage.saveChats(chats)
    }

    val visibleChats = chats.filter { it.isArchived == showArchived }
        .sortedWith(compareByDescending<Chat> { it.isFavorite }.thenByDescending { it.lastMessageTime })

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (showArchived) "Архив" else "Melo", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                },
                navigationIcon = {
                    if (showArchived) {
                        IconButton(onClick = { showArchived = false }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                        }
                    }
                },
                actions = {
                    if (!showArchived) {
                        IconButton(onClick = { showArchived = true }) {
                            Icon(Icons.Default.Archive, contentDescription = "Архив")
                        }
                    }
                    IconButton(onClick = onProfileClick) {
                        Icon(Icons.Default.Person, contentDescription = "Профиль")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    actionIconContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        floatingActionButton = {
            if (!showArchived) {
                FloatingActionButton(
                    onClick = { showCreateMenu = true },
                    containerColor = colors.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Создать")
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (!showArchived) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { StoryItem("Добавить", true, onStoriesClick) }
                    items(4) { i -> StoryItem("История ${i + 1}", false, onStoriesClick) }
                }
                Divider(color = colors.divider)
            }

            if (visibleChats.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (showArchived) "Архив пуст" else "Нет чатов", color = colors.secondaryText)
                }
            } else {
                LazyColumn {
                    items(visibleChats, key = { it.id }) { chat ->
                        ChatListItem(
                            chat = chat,
                            onClick = { onChatClick(chat.id) },
                            onToggleFavorite = {
                                chats = chats.map {
                                    if (it.id == chat.id) it.copy(isFavorite = !it.isFavorite) else it
                                }
                            },
                            onToggleArchive = {
                                chats = chats.map {
                                    if (it.id == chat.id) it.copy(isArchived = !it.isArchived) else it
                                }
                            },
                            onDelete = { chatToDelete = chat }
                        )
                    }
                }
            }
        }
    }

    if (showCreateMenu) {
        AlertDialog(
            onDismissRequest = { showCreateMenu = false },
            title = { Text("Создать") },
            text = {
                Column {
                    TextButton(onClick = { showCreateMenu = false; onNewGroupClick() }) {
                        Icon(Icons.Default.Group, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Новая группа")
                    }
                    TextButton(onClick = {
                        showCreateMenu = false
                        val newChat = Chat(
                            title = "Новый канал",
                            type = ChatType.CHANNEL,
                            lastMessage = "Канал создан"
                        )
                        chats = listOf(newChat) + chats
                    }) {
                        Icon(Icons.Default.Campaign, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Новый канал")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCreateMenu = false }) { Text("Закрыть") }
            }
        )
    }

    chatToDelete?.let { chat ->
        AlertDialog(
            onDismissRequest = { chatToDelete = null },
            title = { Text("Удалить чат?") },
            text = { Text("«${chat.title}» будет удалён.") },
            confirmButton = {
                TextButton(onClick = {
                    chats = chats.filter { it.id != chat.id }
                    chatToDelete = null
                }) { Text("Удалить", color = Color.Red) }
            },
            dismissButton = {
                TextButton(onClick = { chatToDelete = null }) { Text("Отмена") }
            }
        )
    }
}

@Composable
fun ChatListItem(
    chat: Chat,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleArchive: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalMeloColors.current
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(54.dp).clip(CircleShape).background(colors.primary.copy(0.25f))
        ) {
            Text(chat.title.first().uppercase(), color = colors.primary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (chat.isFavorite) {
                    Icon(Icons.Default.Star, null, tint = Color(0xFFFFC107), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(chat.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = colors.onBackground,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(timeFormat.format(Date(chat.lastMessageTime)), fontSize = 13.sp, color = colors.secondaryText)
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val typeLabel = when (chat.type) {
                    ChatType.CHANNEL -> "канал · "
                    ChatType.GROUP -> "группа · "
                    else -> ""
                }
                Text(typeLabel + chat.lastMessage, fontSize = 14.sp, color = colors.secondaryText,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (chat.unreadCount > 0) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(start = 6.dp).background(colors.primary, RoundedCornerShape(12.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(chat.unreadCount.toString(), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.MoreVert, null, tint = colors.secondaryText)
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (chat.isFavorite) "Убрать из избранного" else "В избранное") },
                            onClick = { onToggleFavorite(); showMenu = false },
                            leadingIcon = { Icon(Icons.Default.Star, null) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (chat.isArchived) "Разархивировать" else "В архив") },
                            onClick = { onToggleArchive(); showMenu = false },
                            leadingIcon = { Icon(Icons.Default.Archive, null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Удалить", color = Color.Red) },
                            onClick = { onDelete(); showMenu = false },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color.Red) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StoryItem(title: String, isAdd: Boolean, onClick: () -> Unit) {
    val colors = LocalMeloColors.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(64.dp).clip(CircleShape)
                .background(if (isAdd) colors.surface else colors.primary.copy(0.3f))
        ) {
            if (isAdd) Icon(Icons.Default.Add, null, tint = colors.primary, modifier = Modifier.size(28.dp))
            else Text(title.first().toString(), color = colors.onBackground, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(title, fontSize = 12.sp, color = colors.secondaryText, maxLines = 1)
    }
}
