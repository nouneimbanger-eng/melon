package com.melo.app.ui.theme

import androidx.compose.ui.graphics.Color

// ===== Light Theme =====
val LightPrimary = Color(0xFF2AABEE)          // Telegram-like blue
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF0F0F0)
val LightOnBackground = Color(0xFF000000)
val LightBubbleOut = Color(0xFFEFFDDE)        // Light green bubble
val LightBubbleIn = Color(0xFFFFFFFF)

// ===== Dark Theme =====
val DarkPrimary = Color(0xFF2AABEE)
val DarkBackground = Color(0xFF0E1621)
val DarkSurface = Color(0xFF17212B)
val DarkOnBackground = Color(0xFFFFFFFF)
val DarkBubbleOut = Color(0xFF2B5278)
val DarkBubbleIn = Color(0xFF182533)

// ===== Lime Theme =====
val LimePrimary = Color(0xFFA8E600)
val LimeBackground = Color(0xFF0F1A0F)
val LimeSurface = Color(0xFF1A2E1A)
val LimeOnBackground = Color(0xFFE8FFE8)
val LimeBubbleOut = Color(0xFF3D5C1A)
val LimeBubbleIn = Color(0xFF24331A)

// ===== Purple Theme =====
val PurplePrimary = Color(0xFFBB86FC)
val PurpleBackground = Color(0xFF121212)
val PurpleSurface = Color(0xFF1E1E1E)
val PurpleOnBackground = Color(0xFFFFFFFF)
val PurpleBubbleOut = Color(0xFF4A148C)
val PurpleBubbleIn = Color(0xFF2D1B4E)

// ===== Orange Theme =====
val OrangePrimary = Color(0xFFFF9800)
val OrangeBackground = Color(0xFF1A120B)
val OrangeSurface = Color(0xFF2A1F14)
val OrangeOnBackground = Color(0xFFFFF3E0)
val OrangeBubbleOut = Color(0xFF5D4037)
val OrangeBubbleIn = Color(0xFF3E2723)

// ===== Midnight Theme =====
val MidnightPrimary = Color(0xFF64B5F6)
val MidnightBackground = Color(0xFF0A0E17)
val MidnightSurface = Color(0xFF141A24)
val MidnightOnBackground = Color(0xFFE3F2FD)
val MidnightBubbleOut = Color(0xFF1A237E)
val MidnightBubbleIn = Color(0xFF0D47A1)
