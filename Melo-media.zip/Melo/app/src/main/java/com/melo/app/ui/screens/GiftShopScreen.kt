package com.melo.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.model.GiftRarity
import com.melo.app.data.model.NoxGift
import com.melo.app.data.model.allNoxGifts
import com.melo.app.data.model.upgradeVariants
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftShopScreen(
    noxesBalance: Long,
    ownedGifts: Map<String, Int>,          // giftId to upgradeLevel (0 = base, 1 = upgraded)
    onBuy: (NoxGift) -> Unit,
    onUpgrade: (NoxGift) -> Unit,
    onBack: () -> Unit
) {
    val colors = LocalMeloColors.current
    var selectedGift by remember { mutableStateOf<NoxGift?>(null) }
    var showResult by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Магазин подарков", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFB794F6),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "$noxesBalance",
                            fontWeight = FontWeight.Bold,
                            color = colors.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground,
                    navigationIconContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Text(
                text = "Лимитированные подарки",
                modifier = Modifier.padding(16.dp),
                color = colors.secondaryText,
                fontSize = 14.sp
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(allNoxGifts) { gift ->
                    val ownedLevel = ownedGifts[gift.id] ?: -1
                    GiftCard(
                        gift = gift,
                        ownedLevel = ownedLevel,
                        canAfford = noxesBalance >= gift.basePrice,
                        canAffordUpgrade = noxesBalance >= gift.upgradePrice,
                        onClick = { selectedGift = gift }
                    )
                }
            }
        }
    }

    // Диалог покупки / улучшения
    selectedGift?.let { gift ->
        val ownedLevel = ownedGifts[gift.id] ?: -1
        GiftDetailDialog(
            gift = gift,
            ownedLevel = ownedLevel,
            noxesBalance = noxesBalance,
            onDismiss = { selectedGift = null },
            onBuy = {
                onBuy(gift)
                showResult = "Ты купил «${gift.name}»!"
                selectedGift = null
            },
            onUpgrade = {
                onUpgrade(gift)
                // Случайный результат улучшения
                val variants = upgradeVariants.filter { it.parentGiftId == gift.id }
                val result = variants.randomOrNull()
                showResult = if (result != null) {
                    "Улучшение! Получено: «${result.name}» (${result.rarity})"
                } else {
                    "Подарок улучшен!"
                }
                selectedGift = null
            }
        )
    }

    // Результат
    showResult?.let { message ->
        AlertDialog(
            onDismissRequest = { showResult = null },
            title = { Text("Готово!") },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { showResult = null }) {
                    Text("Ок")
                }
            }
        )
    }
}

@Composable
fun GiftCard(
    gift: NoxGift,
    ownedLevel: Int,
    canAfford: Boolean,
    canAffordUpgrade: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMeloColors.current
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale.value)
            .clickable {
                scope.launch {
                    scale.animateTo(0.92f, spring(stiffness = 700f))
                    scale.animateTo(1f, spring(stiffness = 400f))
                }
                onClick()
            },
        colors = CardDefaults.cardColors(containerColor = colors.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Иконка подарка
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        when (gift.rarity) {
                            GiftRarity.COMMON -> Color(0xFF4A5568)
                            GiftRarity.RARE -> Color(0xFF553C9A)
                            GiftRarity.EPIC -> Color(0xFF6B46C1)
                            GiftRarity.LEGENDARY -> Color(0xFFD69E2E)
                        }.copy(alpha = 0.3f)
                    )
            ) {
                Text(text = gift.emoji, fontSize = 36.sp)
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = gift.name,
                fontWeight = FontWeight.SemiBold,
                color = colors.onBackground,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(4.dp))

            if (ownedLevel >= 0) {
                Text(
                    text = if (ownedLevel >= 1) "Улучшен" else "Куплено",
                    color = Color(0xFF68D391),
                    fontSize = 12.sp
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = Color(0xFFB794F6),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = "${gift.basePrice}",
                        color = colors.onBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GiftDetailDialog(
    gift: NoxGift,
    ownedLevel: Int,
    noxesBalance: Long,
    onDismiss: () -> Unit,
    onBuy: () -> Unit,
    onUpgrade: () -> Unit
) {
    val colors = LocalMeloColors.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(gift.name, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(text = gift.emoji, fontSize = 48.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(12.dp))
                Text(gift.description, color = colors.secondaryText)
                Spacer(Modifier.height(8.dp))
                Text("Цена: ${gift.basePrice} ноксов", fontWeight = FontWeight.Medium)
                Text("Улучшение: ${gift.upgradePrice} ноксов", fontWeight = FontWeight.Medium)
            }
        },
        confirmButton = {
            when {
                ownedLevel < 0 -> {
                    Button(
                        onClick = onBuy,
                        enabled = noxesBalance >= gift.basePrice,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9F7AEA))
                    ) {
                        Text("Купить")
                    }
                }
                ownedLevel == 0 -> {
                    Button(
                        onClick = onUpgrade,
                        enabled = noxesBalance >= gift.upgradePrice,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9F7AEA))
                    ) {
                        Text("Улучшить")
                    }
                }
                else -> {
                    TextButton(onClick = onDismiss) {
                        Text("Уже улучшен")
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )
}
