package com.melo.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melo.app.data.MeloStorage
import com.melo.app.ui.theme.LocalMeloColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoxesScreen(onOpenShop: () -> Unit = {}) {
    val colors = LocalMeloColors.current
    val context = LocalContext.current
    val storage = remember { MeloStorage(context) }
    val scope = rememberCoroutineScope()

    var noxesBalance by remember { mutableStateOf(0L) }
    var totalTaps by remember { mutableStateOf(0L) }
    var ownedGifts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var showShop by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    // Загрузка при старте
    LaunchedEffect(Unit) {
        noxesBalance = storage.noxesBalance.first()
        totalTaps = storage.noxesTaps.first()
        ownedGifts = storage.ownedGifts.first()
        loaded = true
    }

    // Сохранение при изменении
    LaunchedEffect(noxesBalance, totalTaps) {
        if (loaded) storage.saveNoxes(noxesBalance, totalTaps)
    }
    LaunchedEffect(ownedGifts) {
        if (loaded) storage.saveOwnedGifts(ownedGifts)
    }

    val scale = remember { Animatable(1f) }

    if (showShop) {
        GiftShopScreen(
            noxesBalance = noxesBalance,
            ownedGifts = ownedGifts,
            onBuy = { gift ->
                if (noxesBalance >= gift.basePrice) {
                    noxesBalance -= gift.basePrice
                    ownedGifts = ownedGifts + (gift.id to 0)
                }
            },
            onUpgrade = { gift ->
                if (noxesBalance >= gift.upgradePrice) {
                    noxesBalance -= gift.upgradePrice
                    ownedGifts = ownedGifts + (gift.id to 1)
                }
            },
            onBack = { showShop = false }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ноксы", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showShop = true }) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = "Магазин", tint = Color(0xFFB794F6))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onBackground
                )
            )
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Ваш баланс", color = colors.secondaryText, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(36.dp).clip(CircleShape)
                                .background(Color(0xFFB794F6).copy(0.2f))
                        ) {
                            Icon(Icons.Default.Star, null, tint = Color(0xFFB794F6), modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("$noxesBalance", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = colors.onBackground)
                    }
                    Text("Ноксов", color = colors.secondaryText, fontSize = 16.sp)
                }
            }

            Spacer(Modifier.height(32.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(180.dp)
                    .scale(scale.value)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFFB794F6), Color(0xFF9F7AEA), Color(0xFF805AD5))))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        scope.launch {
                            scale.animateTo(0.85f, spring(stiffness = 800f))
                            scale.animateTo(1f, spring(stiffness = 400f))
                        }
                        noxesBalance += 1
                        totalTaps += 1
                    }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Star, null, tint = Color.White, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(6.dp))
                    Text("ТАП", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Нажимай и получай Ноксы", color = colors.secondaryText, fontSize = 14.sp)

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { showShop = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9F7AEA)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.ShoppingBag, null)
                Spacer(Modifier.width(8.dp))
                Text("Магазин подарков", fontSize = 16.sp)
            }

            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$totalTaps", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colors.onBackground)
                    Text("Тапов", fontSize = 13.sp, color = colors.secondaryText)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$noxesBalance", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colors.onBackground)
                    Text("Баланс", fontSize = 13.sp, color = colors.secondaryText)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${ownedGifts.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colors.onBackground)
                    Text("Подарков", fontSize = 13.sp, color = colors.secondaryText)
                }
            }
        }
    }
}
