package com.melo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.melo.app.data.model.Chat
import com.melo.app.data.model.ChatType
import com.melo.app.data.model.Story
import com.melo.app.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "melo_storage")

class MeloStorage(private val context: Context) {

    companion object {
        private val NOXES_BALANCE = longPreferencesKey("noxes_balance")
        private val NOXES_TAPS = longPreferencesKey("noxes_taps")
        private val OWNED_GIFTS = stringPreferencesKey("owned_gifts")
        private val PROFILE = stringPreferencesKey("profile")
        private val CHATS = stringPreferencesKey("chats")
        private val STORIES = stringPreferencesKey("stories")
    }

    val noxesBalance: Flow<Long> = context.dataStore.data.map { it[NOXES_BALANCE] ?: 0L }
    val noxesTaps: Flow<Long> = context.dataStore.data.map { it[NOXES_TAPS] ?: 0L }

    val ownedGifts: Flow<Map<String, Int>> = context.dataStore.data.map { prefs ->
        val raw = prefs[OWNED_GIFTS] ?: ""
        if (raw.isBlank()) emptyMap()
        else raw.split(",").mapNotNull {
            val p = it.split(":")
            if (p.size == 2) p[0] to (p[1].toIntOrNull() ?: 0) else null
        }.toMap()
    }

    suspend fun saveNoxes(balance: Long, taps: Long) {
        context.dataStore.edit {
            it[NOXES_BALANCE] = balance
            it[NOXES_TAPS] = taps
        }
    }

    suspend fun saveOwnedGifts(gifts: Map<String, Int>) {
        val raw = gifts.entries.joinToString(",") { "${it.key}:${it.value}" }
        context.dataStore.edit { it[OWNED_GIFTS] = raw }
    }

    val profile: Flow<UserProfile> = context.dataStore.data.map { prefs ->
        val raw = prefs[PROFILE] ?: ""
        if (raw.isBlank()) UserProfile()
        else {
            val p = raw.split("|")
            UserProfile(
                name = p.getOrElse(0) { "Melo User" },
                username = p.getOrElse(1) { "melo_user" },
                bio = p.getOrElse(2) { "" }
            )
        }
    }

    suspend fun saveProfile(profile: UserProfile) {
        val raw = listOf(profile.name, profile.username, profile.bio).joinToString("|")
        context.dataStore.edit { it[PROFILE] = raw }
    }

    val chats: Flow<List<Chat>> = context.dataStore.data.map { prefs ->
        val raw = prefs[CHATS] ?: ""
        if (raw.isBlank()) defaultChats()
        else {
            raw.split(";").mapNotNull { line ->
                val p = line.split("~")
                if (p.size < 8) return@mapNotNull null
                Chat(
                    id = p[0],
                    title = p[1],
                    type = try { ChatType.valueOf(p[2]) } catch (e: Exception) { ChatType.PRIVATE },
                    lastMessage = p[3],
                    lastMessageTime = p[4].toLongOrNull() ?: System.currentTimeMillis(),
                    unreadCount = p[5].toIntOrNull() ?: 0,
                    isFavorite = p[6] == "1",
                    isArchived = p[7] == "1"
                )
            }
        }
    }

    suspend fun saveChats(chats: List<Chat>) {
        val raw = chats.joinToString(";") { c ->
            listOf(
                c.id,
                c.title.replace("~", " ").replace(";", " "),
                c.type.name,
                c.lastMessage.replace("~", " ").replace(";", " "),
                c.lastMessageTime.toString(),
                c.unreadCount.toString(),
                if (c.isFavorite) "1" else "0",
                if (c.isArchived) "1" else "0"
            ).joinToString("~")
        }
        context.dataStore.edit { it[CHATS] = raw }
    }

    val stories: Flow<List<Story>> = context.dataStore.data.map { prefs ->
        val raw = prefs[STORIES] ?: ""
        if (raw.isBlank()) emptyList()
        else {
            raw.split(";").mapNotNull { line ->
                val p = line.split("~")
                if (p.size < 3) return@mapNotNull null
                Story(
                    id = p[0],
                    userId = "me",
                    mediaPath = "",
                    caption = p[1],
                    timestamp = p[2].toLongOrNull() ?: System.currentTimeMillis()
                )
            }
        }
    }

    suspend fun saveStories(stories: List<Story>) {
        val raw = stories.joinToString(";") { s ->
            listOf(s.id, s.caption.replace("~", " ").replace(";", " "), s.timestamp.toString())
                .joinToString("~")
        }
        context.dataStore.edit { it[STORIES] = raw }
    }

    private fun defaultChats() = listOf(
        Chat(id = "1", title = "Избранное", lastMessage = "Важные сообщения", isFavorite = true),
        Chat(id = "2", title = "Семья", type = ChatType.GROUP, lastMessage = "Мама: Купи хлеб", unreadCount = 3),
        Chat(id = "3", title = "Друзья", type = ChatType.GROUP, lastMessage = "Пойдём гулять?"),
        Chat(id = "4", title = "Новости Melo", type = ChatType.CHANNEL, lastMessage = "Обновление приложения")
    )
}
